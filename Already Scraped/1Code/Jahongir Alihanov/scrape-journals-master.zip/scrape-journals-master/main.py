import time

import pandas as pd
from selenium import webdriver

driver = webdriver.Chrome("/Users/jahongiralihanov/Downloads/chromedriver")
url = "https://onlinelibrary.wiley.com/loi/14680262"

driver.maximize_window()
driver.get(url)
uls = driver.find_element_by_class_name('loi__list')
all_li = uls.find_elements_by_tag_name("li")
each_links = list()
for loop in all_li:
    try:
        a = loop.find_element_by_tag_name("a")
        each_links.append(a.get_attribute("href"))
    except:
        li_inside_li = loop.find_elements_by_tag_name("li")
        for lop in li_inside_li:
            a = loop.find_element_by_tag_name("a")
            each_links.append(a.get_attribute("href"))
    finally:
        continue

each_page_links = list()
for link in each_links:
    driver.get(link)
    lis_in_a_page = driver.find_element_by_class_name("loi__issues").find_elements_by_tag_name("li")
    for li in lis_in_a_page:
        try:
            a = li.find_element_by_tag_name("a")
            each_page_links.append(a.get_attribute("href"))
        except:
            continue

final_scape_links = list()
# for link in each_page_links:
#     try:
#         driver.get(str(link))
#         items = driver.find_elements_by_class_name("issue-item")
#         print(len(items))
#         for item in items:
#             try:
#                 a = item.find_element_by_xpath('//a[@class="issue-item__title visitable"]')
#                 final_scape_links.append(a.get_attribute("href"))
#             except Exception as e:
#                 print(e.args)
#                 continue
#     except:
#         pass

for link in each_page_links:
    try:
        driver.get(str(link))
        abstract_links = driver.find_elements_by_link_text("Abstract")
        for link in abstract_links:
            try:
                final_scape_links.append(link.get_attribute("href"))
            except:
                pass
    except:
        pass

titles = []
issues = []
abstracts = []
authors1 = []
authors2 = []
authors3 = []
authors4 = []
none_english = []

for final_link in final_scape_links:
    try:
        driver.get(final_link)
        time.sleep(2)
        title = driver.find_element_by_class_name("citation__title").text
        abstract = driver.find_element_by_xpath('//div[@class="article-section__content en main"]').text
        issue = driver.find_element_by_class_name("cover-image__details").text
        author1 = ""
        author2 = ""
        author3 = ""
        author4 = ""
        authors = driver.find_element_by_class_name("accordion-tabbed").find_elements_by_class_name("author-name")
        try:
            author1 = authors[0].text
            author2 = authors[1].text
            author3 = authors[2].text
            author4 = authors[3].text
        except:
            pass
        titles.append(title)
        abstracts.append(abstract)
        issues.append(issue)
        authors1.append(author1)
        authors2.append(author2)
        authors3.append(author3)
        authors4.append(author4)
        none_english.append("")
    except:
        pass

    dataframe = pd.DataFrame(
        {
            "Title": titles,
            "Issue": issues,
            "Abstract": abstracts,
            "Author1": authors1,
            "Author2": authors2,
            "Author3": authors3,
            "Author4": authors4,
            "NonEnglish": none_english
        }
    )
    dataframe.to_excel("OnlineLibrary.xlsx", index=True, encoding="utf-8-sig")
    print("success")
    driver.quit()
