import time

import requests
import pandas as pd

from selenium import webdriver
from bs4 import BeautifulSoup


def override_recaptcha(driver):
    try:
        input = driver.find_element_by_xpath('//div[@class="recaptcha-checkbox goog-inline-block recaptcha-checkbox-unchecked rc-anchor-checkbox"]')
        input.click()
        print("clicked")
        time.sleep(5)
    except Exception as e:
        print(e.args)
        pass

url = "https://academic.oup.com/restud/issue-archive"
driver = webdriver.Chrome("/Users/jahongiralihanov/Downloads/chromedriver")
driver.maximize_window()
driver.get(url)
driver.get(url)
override_recaptcha(driver)
div = driver.find_element_by_xpath('//div[@class="widget widget-IssueYears widget-instance-OUP_Issues_Year_List"]')

all_year_links = list()
links = div.find_elements_by_tag_name("a")
for link in links:
    try:
        all_year_links.append(link.get_attribute('href'))
    except:

        pass
year_detail_links = list()
for link in all_year_links:
    time.sleep(2)
    try:
        driver.get(link)
        override_recaptcha(driver)
        all_links = driver.find_elements_by_id("item_ResourceLink")
        for lin in links:
            year_detail_links.append(lin.get_attribute('href'))
    except:
        pass

print(year_detail_links)

driver.quit()