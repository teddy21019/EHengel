import time

import requests
import pandas as pd

from selenium import webdriver
from bs4 import BeautifulSoup

url = "https://www.journals.uchicago.edu/loi/jpe"
driver = webdriver.Chrome("/Users/jahongiralihanov/Downloads/chromedriver")
driver.maximize_window()
driver.get(url)

time.sleep(3)

should_click = 2010
one_by_one = 2020
h3 = driver.find_elements_by_tag_name("h3")
for h in h3:
    try:
        a = h.find_element_by_xpath('//a[@aria-expanded="false"]')
        a.click()
        time.sleep(3)
    except:
        print("eror")
        pass

area_expended = driver.find_elements_by_xpath('//a[@aria-expanded="false"]')
for are in area_expended:
    try:
        are.click()
    except:
        pass
all_items = driver.find_elements_by_class_name("issue-items__body")
print(len(all_items))
sing_links = list()
for item in all_items:
    try:
        sing_links.append(item.get_attribute('href'))
    except:
        pass

print(sing_links)

